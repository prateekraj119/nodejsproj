var express = require('express');
var router = express.Router();
var details = require('../controller/load_details');


/* GET home page. */
router.post('/api/load_details', details.getDetailsByID);


module.exports = router;
