var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var conn = require('../config/db');


exports.getDetailsByID = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'POST');
    res.header("Access-Control-Allow-Headers", "accept, content-type");
    var emp_id = req.body.id;

    console.log(emp_id);
   // conn.
    conn.query('CALL users(?)',[emp_id],function (err, results) {
     if(err) {
         console.log(err)
     }
     console.log(results);
     return res.send(results);
    });


};