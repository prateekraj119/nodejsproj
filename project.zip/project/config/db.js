var mysql = require('mysql');
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'password',
    database: 'Users',
    port: '3306'
});

connection.connect(function(err) {
    if (err) throw err;
    console.log('Mysql Connected...');
});

module.exports = connection;