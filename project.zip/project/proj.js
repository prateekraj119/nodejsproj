const path = require('path');
const express = require('express');
const hbs = require('hbs');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();

const conn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'crewcrare',
  port: '3306'
});
conn.connect((err) =>{
  if(err) throw err;
  console.log('Mysql Connected...');
});

app.set('views',path.join(__dirname,'views'));
app.set('view engine', 'hbs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.get('/', function(req, res) {
  res.render('main.hbs');
});


app.post('/load_details', function(req, res) {

var emp_id = req.body.crew_id;

    console.log(emp_id);
  
    conn.query('CALL crew_details(?)',[emp_id],function (err, results) {
      if (err)throw err;
          res.render('Crew_roaster',{
            roaster_details:results[0]
      });
});
});
  app.listen(2003);
  console.log("Running at Port 2003");