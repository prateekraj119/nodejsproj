CREATE DEFINER=`root`@`localhost` PROCEDURE `users`(In emp_id VARCHAR(45))
BEGIN
SELECT 'id','name','address','dob','email' FROM users.details LIMIT 2000000;

--  WHERE WEEK (duty_date) = WEEK('2020-02-27') + 1 AND YEAR( duty_date) = YEAR( current_date ) and id=emp_id;
END